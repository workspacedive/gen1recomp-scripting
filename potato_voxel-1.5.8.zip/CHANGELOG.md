# Changelog

## [1.5.8] - 2026-08-13

### Fixed

- **Trees, bushes, signs and planters had no shadow at the `CONTACT` rung.**
  1.5.7 kept the contact decals under *characters* but those are drawn from
  the `posed` list — actors only. Every static prop got its grounding from
  the shadow map alone, so removing the directional pass left them sitting
  on flat, unshaded floor.

  The underlying cause is older than the CONTACT rung and was simply
  invisible before it. A cell carrying a prop is marked `S.skip`, and
  `ChunkMesher.heightAt` reads `skip` back as **height 0**. That is correct
  for meshing — the cell must emit no box, because the prop's own quads
  stand there and a box would be a second, wrong solid — but the ambient
  occlusion term used the same function. It asked "how tall is my
  neighbour", heard "nothing", and shaded ground beside a tree exactly like
  open field. With a shadow map running nobody could tell: the tree's own
  cast covered the same ground.

  Two questions, now asked separately:

  | query | answers | prop cell |
  |---|---|---|
  | `heightAt` | "what box do I build here" | 0 — unchanged |
  | `occluderAt` *(new)* | "how much sky does that take away" | the prop's height |

  `Structures` records an occluding height per claimed cell (`S.propH`) at
  all five sites where the prop path claims one — round trees, planter
  sprays, cylinders/stumps and both prop-cluster branches. Ground beside a
  prop now darkens to **78%**, an inside corner between two to **35%**, and
  open ground stays at exactly 1.0: this only *adds* a seam.

### Changed

- `MeshCache.GEOMETRY_VERSION` 17 → 18. The shades are baked into the vertex
  stream, so every mesh cached before this change would still show unshaded
  floor around every prop. The bump discards them.

### Testing

- New suite `tests/prop_contact_ao_test.lua` (23 checks): the map is
  allocated and written at every prop site, a tree occludes more than a
  sign, `heightAt` **still** returns 0 for a prop cell (the mesher must not
  grow a ghost box), the AO term reads `occluderAt` and no longer
  `heightAt`, the darkening is arithmetically re-derived from the shipped
  constants, and the cache version is bumped.
- Mutation-proven: AO reverted to `heightAt` → 2 failures; `propH` never
  written → 1; cache version left at 17 → 1; `heightAt` leaking the prop
  height (ghost boxes) → 1.

## [1.5.7] - 2026-08-13

### Added

- **`SHADOWS = CONTACT` — a third rung: overcast.** No cast shadows
  anywhere, ground and walls evenly lit, but the small contact shadow under
  every character, Pokemon and bush **stays**.

  The reported fault was several long, hard, parallel bands raking
  diagonally across the whole town, "as if a giant fence were casting onto
  the city". Diagnosis, finally correct: **that is the directional sun
  working as designed.** At a low elevation the shear reaches `K_MAX = 2.0`,
  so every object throws a shadow up to twice its own height, and one
  distant light casts parallel rays — many long parallel bands, sharing one
  angle, with their casters off-screen or too small to connect to them. No
  bias value can remove that; it is not an artefact.

  So the fix is not to weaken the sun but to make the two effects
  **separable**, which they were not:

  | rung | cast shadows | contact shadows |
  |---|---|---|
  | `ON` | yes | yes |
  | `CONTACT` *(new)* | **no** | **yes** |
  | `OFF` | no | no |

  `OFF` took both, so escaping the bands used to cost every figure its
  footing — exactly what the `NO SUN` probe rung showed. `CONTACT` is the
  physically honest pairing: an overcast sky has no sun to cast with, yet
  every object still occludes the sky above the ground it stands on.

### Changed

- `ShadowSettings` gains `directional()` and `contact()` beside the existing
  `enabled()`. The directional pass and the decal pass now ask separate
  questions instead of sharing one flag.
- `BattleScene` asks `directional()` too, so an arena cannot keep throwing
  cast shadows that the overworld has stopped throwing.
- The stored values remain `true` / `false` for ON / OFF, with `"contact"`
  added between them. Saves from every earlier version read back as the mode
  their owner chose; a tidy three-string set would have silently rewritten
  everyone to the first rung.

### Fixed

- `shadow_sanity_test` matched the literal text `ShadowSettings.enabled()`
  when checking the indoor gate, and failed when the accessor was renamed
  even though the gate was intact. It now matches the substance — that the
  directional gate is conjoined with `outdoorNow` — rather than one spelling
  of it.

### Testing

- New suite `tests/shadow_contact_test.lua` (29 checks): all three rungs
  against all three accessors, the save-compatible value set, both call
  sites, the arena's agreement with the overworld, and — the trap this rung
  exists to avoid — that the decals are **not** conditioned on a shadow map
  existing. Mutation-proven: re-coupling the decals to the directional gate
  → 3 failures; directional pass back on `enabled()` → 1; string values
  breaking old saves → 2; arena left on `enabled()` → 2.

## [1.5.6] - 2026-08-13

### Fixed

- **The diagonal streaks outdoors — the real cause, found by the probe.**
  `NO SUN` removed them; `1 TAP`, `NO RIM` and `NO FOG` did not. That
  narrows it to the shadow *compare* itself. The decisive observation was
  the user's: the streaks **move, and reverse direction** over time.

  They do, because **the sun moves**. `DayNight.applyRig` rewrites
  `ShadowMap.KX/KZ` every frame along a sunrise-to-sunset arc — bearing from
  −70° through 33° to 250°, elevation from ~6° up to 61° and back. The
  streaks run upper-right to lower-left in the morning and upper-left to
  lower-right in the afternoon because they are aligned to the **sun's own
  frame**, and that frame rotates through the day.

  Every previous fix treated `SLOPE` as one number. It cannot be: the depth
  ramp across a texel is `tan(theta)` to the light, so the requirement
  changes hour by hour. Sweeping the arc against the fixed 4.8:

  | time | elevation | ramp needed | slack | verdict |
  |---|---|---|---|---|
  | t=60 | 18.9° | 3.60 | 4.8 | ok |
  | t=180 | 49.5° | 10.68 | 4.8 | **acne** |
  | t=220 | 55.9° | **18.71** | 4.8 | **acne** |
  | t=300 | 61.2° (noon) | 3.69 | 4.8 | ok |
  | t=540 | 18.9° | 8.53 | 4.8 | **acne** |

  Noon — the one sun 1.5.3 derived against — is among the *best* hours.
  That is why the fix looked right and changed nothing.

  `ShadowMap.slopeNow()` now computes the requirement from the sun in force,
  taking the worst ramp over the face orientations this world builds, with
  `SLOPE_MARGIN = 1.3` headroom, a `GRAZE` cut-off so faces at the
  terminator do not send `tan()` to infinity, and a `SLOPE_MAX` ceiling so
  the cure never becomes Peter-panning. `SLOPE = 4.8` survives as the floor.

  Result across the full arc: **0 hours short of slack**, worst headroom
  **1.30×**, largest slack 4.18 world px, snugged contact gap 0.42 px.

### Testing

- `tests/shadow_bias_test.lua` rewritten (17 checks). It no longer examines
  one sun: it **sweeps the entire day** at 10-second steps and asserts every
  hour holds, that shadows stay attached at the widest slack, and — as
  positive proof the dynamic version earns its keep — that a *fixed* slope
  would fail **34** of the sampled hours.
- Mutation-proven: reverting `fit()` to the constant → 1 failure; margin
  removed → 1; ceiling too low → 2; ceiling absurdly high → 3.
- The last of those found a hole worth recording: with the ceiling set to
  40 the suite first **passed**, because this world's sun never reaches the
  clamp, so nothing exercised it. The clamp is now bounded directly rather
  than only through the arc.

## [1.5.5] - 2026-08-13

### Added

- **`STREAK PROBE` — a diagnostic row in the settings menu.** Two releases
  have now proposed a cause for the "4 long diagonal streaks across the
  whole screen, outdoors" report and neither was it. Static reading has not
  settled it, and each guess costs a release, so this replaces guessing with
  bisection the player can run in under a minute. Each rung silences one
  suspect; whichever one makes the streaks vanish **names the pass**.

  | rung | silences | what it proves |
  |---|---|---|
  | `OFF` | nothing | baseline — streaks should be visible |
  | `NO SUN` | the entire shadow pass | survives ⇒ **no part of the shadow system** is responsible |
  | `1 TAP` | the 2×2 PCF spread | stops ⇒ the fault is tap spacing / lookup quantisation |
  | `NO RIM` | the frustum-edge fade | stops ⇒ it **is** the rim: four borders, four lines |
  | `NO FOG` | the distance/height haze | stops ⇒ an interpolated per-vertex term is banding |
  | `FLAT` | shadow + fog + tint + grid | survives ⇒ **not shading at all**, it is geometry |

  `NO RIM` and `FLAT` are the two that matter most for a count of exactly
  four. The shadow frustum has four borders, and the terrain body sits
  inside a four-sided border ring — both are shapes that can produce four
  world-axis-aligned lines, which the rotated camera renders as diagonals
  running upper-right to lower-left.

  A normal frame sends `probeFilter = 1` and `probeRim = 1`, where
  `sunTexel * 1` and `mix(1.0, edge, 1.0)` are bit-identical to the previous
  code — `OFF` is a true no-op, not "the shader with a zero in it".

### Changed

- `QualityMode` deliberately does **not** list the probe in `PRESETS`,
  `matches()` or `applyMode()`. Every other setting must be listed or it
  silently stops participating in the quality modes; the probe is the
  documented exception, because otherwise switching a pass off to find a
  fault would knock the quality mode to CUSTOM and force the player to
  repair their settings afterwards.

### Testing

- New suite `tests/stripe_probe_test.lua` (50 checks): every rung gates
  exactly the passes it advertises and no others, `OFF` is a true no-op,
  `FLAT` is terminal (silences strictly more than any other rung, so the
  bisection has no hole), the wiring is present in all three call sites, and
  `matches()`/`applyMode()` are asserted **not** to consult the probe.

## [1.5.4] - 2026-08-13

### Fixed

- **The long diagonal streaks across the whole screen outdoors.** Present in
  every release including the original 1.4.4 — **not** a regression from the
  1.5.2 sun change, and not shadow acne. The cause is shader precision.

  In GLSL ES — phones, and love.js/WebGL, which is what this actually runs
  on — a `varying` with no precision qualifier gets **mediump** in the
  fragment stage. mediump is fp16: ten bits of mantissa, one ulp in the top
  half of 0..1 is `2^-11`. Three varyings could not survive that, and all
  three feed the shadow path:

  | varying | carries | what fp16 does to it |
  |---|---|---|
  | `Voxel3D.vSun` | shadow-map **address** | 1 ulp = **0.5 texel** @1024, **1.0** @2048 |
  | `ShadowMap.vDepth` | the depth being **packed into 2 bytes** | quantised before the split; low byte carries nothing |
  | `Water.vSun` | the same lookup, on water | as above |

  Two distinct failures follow. The 2×2 filter's taps sit half a texel apart
  *by design*, so once the coordinate feeding them quantises at that same
  scale the four taps collapse onto one texel and the soft edge falls back
  to a staircase. And the depth compare resolves broad **equal-depth
  plateaus** instead of a ramp. Those plateaus are level sets of depth *in
  the sun's frame*, so they lie perpendicular to the sun's bearing — which
  is why they read as a few wide diagonals lying across the entire screen
  rather than as speckle, and why **no amount of depth bias removes them**:
  bias shifts every plateau together.

  All three are now `LOVE_HIGHP_OR_MEDIUMP`, matching `vGrid` and `vBent`,
  which already carried the qualifier for exactly this reason. Free where
  highp is the default (desktop); the whole fix where it is not.

### Testing

- New suite `tests/shader_precision_test.lua` (20 checks): every varying
  that carries an address, a coordinate or a depth must declare the
  qualifier, the scene and water shaders must agree (one map, one
  precision), the fp16 arithmetic in the comments is re-derived, and a bare
  `highp` is rejected (desktop GL has no such keyword). Mutation-proven:
  reverting `vSun` → 2 failures; `vDepth` → 1; bare `highp` → 4.

### Changed

- `ShadowMap.SLOPE` stays at the 4.8 derived in 1.5.3. That derivation was
  correct on its own terms — the slope bias *was* mis-calibrated for the
  raised sun — it simply was not the cause of the streaks.

## [1.5.3] - 2026-08-13

### Fixed

- **Long diagonal streaks lay across the world outdoors, cast by nothing.**
  A regression introduced by 1.5.2, and the mechanism is worth stating
  plainly: **it was not a stray caster. It was lit surfaces shadowing
  themselves** — classic shadow acne, which runs diagonally because the
  moire follows the depth ramp in the sun's own frame rather than the world
  or screen grid.

  A surface's depth ramps across one shadow-map texel by `tan(theta)`, the
  angle between its normal and the light. That makes `ShadowMap.SLOPE` **a
  function of where the sun is** — and 1.5.2 raised the sun from 44.65 to
  61.19 degrees while leaving SLOPE at 3.1, a value derived for the old sun.

  Raising the sun made the grazing angle onto near-vertical faces *worse*:

  | lit surface | ramp @ 44.65° | ramp @ 61.19° |
  |---|---|---|
  | ground | 1.012 | 0.550 |
  | wall, east | 1.343 | 2.260 |
  | **wall, south** | **2.386** | **3.686** |
  | roof 45° NW | — | 3.346 |

  The worst lit surface needed **+54.5%** more slack, so headroom on the
  widest rung fell from 1.55× to **1.00×** and big lit walls began failing
  their own depth compare. Ground actually improved, which is why the
  streaks appeared on walls and cliffs rather than on the floor.

  `SLOPE` is re-derived for the current sun: **4.8** (worst lit surface
  3.686, 1.30× headroom).

### Testing

- New suite `tests/shadow_bias_test.lua` (11 checks). It **derives** the
  requirement from the configured sun instead of asserting a literal, so
  retuning the sun retunes the expectation — this exact regression cannot
  recur silently. Proven by mutation: restoring `SLOPE = 3.1` under the new
  sun → **4 failures**; over-correcting to 12.0 (shadows would detach from
  their casters) → 1 failure. Restored, mirror diffed, 11/11.
- It also checks the light frustum still reaches as far as a shadow from the
  tallest geometry travels — a second, independent way to get streaks from
  nothing.
- The old `SLOPE` comment cited `tests/voxel_acne_probe.lua` as its
  measurement. **That file does not exist in this tree and never shipped**,
  so the number could not be re-checked when the sun moved. The new suite
  replaces that dangling reference with a live derivation.

## [1.5.2] - 2026-08-13

### Fixed

- **Shadows were exaggeratedly long.** `hypot(KX, KZ)` was 1.01 — a sun only
  44.65 degrees up, so every shadow was as long as its caster was tall. A
  48px tree threw **3.04 tiles** of shadow across the path; on a ten-tile
  route that is a third of the screen.

  The geometry here is less forgiving than a real sun: shadows land on a
  nearly flat plane viewed from a fixed 35-degree camera, so their full
  length is always on screen and nothing ever foreshortens them. Raised to
  **61.19 degrees** (shear 0.55), which puts a tree at **1.65 tiles** — long
  enough to read as a direction and to model the object, short enough to stay
  within the space the object occupies.

  The compass **bearing is preserved exactly**: 32.904 degrees against the
  previous 32.905. The sun was raised straight up, not swung, so
  `Voxel3D.FACE_SHADE`, the baked contact shading in `ChunkMesher` and every
  asset authored against "the sun hangs in the southeast" remain correct.

- **Indoors the sun shone anyway.** The shadow pass was gated on the quality
  rung and the player's row only — never on whether the map has a sky. Under
  a roof this was wrong twice over: the shear threw shadows **through the
  walls and out the other side** (reported as "they break out"), and a hard
  directional sun contradicted the hour's tint, the window glass and the sky,
  all of which already answer `outdoor = false` in the same frame.

  The pass now also requires `outdoorNow` — the same value the rest of the
  lighting uses, derived from the engine's own `Map.isOutdoor`. Evaluated
  before the call, so an interior pays nothing for the pass at all. Canopy
  maps (Viridian Forest) still count as outdoor and keep their sun, which is
  correct: a forest floor is lit through the leaves.

### Testing

- New suite `tests/shadow_sanity_test.lua` (14 checks), **proven by
  mutation**: restoring the 45-degree sun → 3 failures; swinging the bearing
  while keeping the length → 2; removing the indoor gate → 2. Restored,
  mirror diffed, 14/14.
- The assertions are on the physics — elevation in degrees, bearing, shadow
  length in tiles — not on the raw constants, so they keep their meaning if
  the sun is retuned again.

## [1.5.1] - 2026-08-13

### Fixed

- **The perspective was anisotropically stretched.** Reported as "the
  perspectives are sometimes shifted", and it was real and measurable.

  `Voxel3D.viewProjection` built its projection with `vw / vh` — the shape of
  the requested WORLD VIEW — while the scene was drawn into a canvas of a
  different shape. Two independent roundings separate the two:

  1. The engine's `Renderer:worldViewSize` computes `math.ceil(pw / sp)` and
     then **forces both axes even** (so `Camera:follow` lands on integer
     pixels). Each step moves an axis by up to a pixel, independently.
  2. RENDER SCALE rounds again: `floor(rw * rs + 0.5)`, per axis.

  `Mat4.perspective` scales X by `1/aspect` and leaves Y alone, so a
  mismatched ratio stretches the scene **horizontally only**. That is why it
  reads as a shifted perspective rather than as a zoom: squares stop being
  square, and the drift grows with distance from the frame centre.

  Measured on the reporting device (440×956, engine zoom 3): the world view
  is 148×320, aspect 0.46250 against the canvas's true 0.46025 — **0.489%**
  of horizontal stretch and **5.8 display pixels** of drift at the frame
  edge. Worst case across tested devices and rungs is **0.577%** (1280×720,
  zoom 3, RENDER SCALE 33%). It is exactly 0 whenever the divisions happen to
  come out even, which is why it looked intermittent.

  All three aspect users now go through one `viewAspect()` helper that
  answers with the bound canvas's own shape: the orbit projection, the
  placed-camera projection, and — importantly — the **sky's ray fan**, which
  would otherwise slide the horizon against the world it belongs to.

  A VR eye is deliberately left alone: it brings an off-centre frustum that
  no single aspect ratio can express, and forcing one would break stereo.
  The headless fallback (no canvas bound) keeps the previous behaviour.

### Testing

- New suite `tests/aspect_test.lua` (11 checks), **proven by mutation**:
  reverting `viewAspect` → 1 failure; reverting the orbit projection → 2;
  reverting the sky ray fan → 2. Restored, mirror diffed, 11/11.
- The suite asserts the *property* — a world square must cover equal
  fractions of the frame's width and height — rather than a specific matrix,
  and cross-checks that the measured stretch equals the computed aspect
  error exactly.
- It also asserts that the engine's rounding really does diverge (9 of 12
  device/zoom combinations), so the suite reports it if the fix ever becomes
  unnecessary instead of silently passing.
- `perspektive.svg` overlays the correct and the stretched ground grid.

## [1.5.0] - 2026-08-13

### Added

- **Shadows are filled by the sky instead of faded to black.** A shadowed
  surface is not a darker copy of a lit one: direct sun is blocked there, but
  the whole sky still lights it — and the sky is blue. The scene shader
  multiplied by a scalar `sun`, so every shadow ran straight toward black,
  which is most of why untinted shadow reads as a filter rather than as
  shade.

  `DayNight.shadowTint(outdoor, t)` now supplies the colour of light inside
  shadow, blended across the **same phase weights** `DayNight.tint` uses, so
  the hour's light and its shadows can never disagree about the time. The
  warm key / cool fill split it produces is the complementary contrast a
  painter puts in deliberately, and it is what makes a single object read as
  having volume.

  Derived rather than invented, in three respects:

  - **Day leans blue** (0.82 / 0.88 / 1.06) because the sun is warm-white and
    what remains in shade is sky.
  - **Night is nearly neutral** (0.96 / 0.98 / 1.02): the key light is
    already the cool moon, so there is no warm sun for shadow to be the
    complement of, and pushing further blue would only crush the picture.
  - **Indoors is exactly neutral.** No sky, no fill — otherwise every cave
    turns blue.

  Shadow depth is normalised by `sunDark` before the fill is applied, so how
  blue a shadow gets does not secretly depend on how dark shadows are set.
  With shadows off the whole term is guarded out and the result is bit-exact
  the previous flat-lit diorama.

- `lib/Water.lua` carries the identical formula, so a shoreline and the water
  touching it cannot disagree about the colour of their own shadows.

### Testing

- New suite `tests/shadow_tint_test.lua` (34 checks), **proven by mutation**:
  dropping the `sunDark` guard → 1 failure; giving night the full daylight
  tint → 1 failure; giving indoors a sky → 1 failure. Restored, mirror
  diffed, 34/34.
- The suite samples the dial across a full cycle and requires the tint to
  move continuously (largest step < 0.05), so no phase boundary can pop.
- `schattenfarbe.html` renders the before/after swatches for five surfaces
  across four phases.

## [1.4.9] - 2026-08-13

### Added

- **SHARPNESS row (OFF / LOW / MEDIUM / HIGH).** The scene is resampled in
  both directions — RENDER SCALE below 100% stretches a smaller canvas up,
  ANTI-ALIAS folds a larger one down — and resampling is what costs real
  detail. Bilinear reconstruction is a low-pass filter, so at 50% every
  silhouette is rebuilt from a quarter of the samples and comes back soft.
  The fold now runs an unsharp pass over the same draw it already performed.

  MEDIUM (0.25) is the default and is exactly the constant `AntiAlias.SHARP`
  was hard-coded to, so the picture does not change on upgrade unless asked.
  OFF is a **separate code path**, not a zero handed to the shader, so "off"
  is provably the previous behaviour.

  The unsharp is **clamped to the local neighbourhood**, which prevents the
  usual overshoot ring on the very high-contrast edges this art style is
  built from — a black outline against bright grass would otherwise grow a
  white halo. The radius is measured in **display** pixels, so the halo is
  the same visual width at 75% and at 33% rather than tripling with the
  scale factor.

### Changed

- `AntiAlias.SHARP` is no longer a hand-tuned constant read only by the AA
  fold; both folds now read the one SHARPNESS value. Sharpening a
  supersampled down-fold and a sub-native up-fold are the same problem in
  opposite directions, and a player should not have to know which path their
  quality mode happens to take.
- All four quality presets carry `sharp = 0.25`, so landing on HIGH / MEDIUM
  / LOW / POTATO does not immediately read as CUSTOM. It is deliberately not
  lowered on the cheap rungs: POTATO renders at 33% and needs it most, and
  the pass is one extra draw over a fold that already happens.
- `Upscale.kind()` was dead code returning `"none"`; it now reports
  `"bilinear"` or `"unsharp"` truthfully.

### Testing

- New suite `tests/sharpness_test.lua` (30 checks), **proven by mutation**:
  tying the radius to source texels instead of display pixels → 3 failures;
  binding the shader when OFF → 1 failure; reverting the AA fold to the old
  constant → 1 failure. Restored and re-confirmed 30/30, with the mirror
  diffed against the working copy.

## [1.4.8] - 2026-08-13

### Fixed

- **Turning SHADOWS on made the game refuse to start.** Reported from an
  iPhone: after enabling the setting the window never opened again, so the
  option could not be turned back off from inside the game.

  `SpriteBillboards.buildShadowBlob` stitches the contact-shadow disc as a
  triangle fan and passed its centre vertex as index `0`. `Mesh:setVertexMap`
  has two variants with **different index bases**: a table map is `[1,
  vertexCount]`, while a `Data` map is `[0, vertexCount - 1]`. This one
  builds a table, so LOVE rejected it with `Invalid vertex map value: 0` —
  thrown from the C layer, which is why the crash carried no Lua traceback.
  The blob is built lazily the first time an actor decal is drawn, and with
  shadows on that happens during the first scene build, before a frame is
  ever presented. The centre is now `1` and the rim `2..9`, and the wrap-around
  triangle is generated by the loop instead of being written out by hand.

  The mod's other three table maps (`ForestAtmos`, `StadiumRig` via
  `StadiumPack`, `Voxel3D.newMesh`) were audited against the same confusion
  and are all correctly 1-based; the one `Data` map (`ChunkMesher`, fed by
  `MeshCache.flattenQuads`) is correctly 0-based. This was the only site
  that mixed the conventions.

- **The failure repeated silently once per frame.** `VoxelScene`'s decal
  pass is `pcall`-wrapped and logged `actor decal pass aborted` on every
  frame instead of disabling itself. It now gives up after repeated
  failures, so one broken decal degrades to "no contact shadows" rather
  than to an endless log.

### Testing

- New suite `tests/shadow_blob_test.lua` (16 checks) builds the blob against
  a `love.graphics` stub that enforces the documented table-map range, and
  asserts the fan closes with all 8 triangles and no gap. Confirmed to fail
  (4 failures, `Invalid vertex map value: 0`) before the fix.
- The existing `voxel_geometry_test` did range-check indices, but only those
  from `ChunkMesher.geometry`; the blob is built in another module the suite
  never reached. That is the gap this suite closes.

## [1.4.7] - 2026-08-13

### Fixed

- **Terrain was lit by a different sun than the one casting its shadows.**
  `Voxel3D.FACE_SHADE` was six hand-typed constants, and they had drifted
  out of agreement with the rest of the mode. The shadow pass throws from
  `(KX, KZ) = (-0.85, -0.55)` — a sun standing SOUTH-EAST, and appreciably
  more east (alignment 0.60) than south (0.39). The table nevertheless made
  SOUTH the brightest flank at 0.90, ahead of east at 0.84. So a wall's flat
  shading said the light came from one direction while the shadow falling
  across that same wall said another, and characters disagreed with the
  ground they stood on, because `StadiumRig` had already been converted to a
  real diffuse term against `ShadowMap.sunDir()` while this table stayed
  hand-tuned. The source comment even recorded an earlier drift ("back when
  the sun sat due northwest"), which is what a constant maintained by hand
  eventually does.

  The six values are now derived from `ShadowMap.sunDir()` — the same vector
  the shadow pass and the character rig use — so the three agree by
  construction instead of by maintenance. Two deliberate choices in how:

  - **Half-Lambert, not a clamped dot.** A straight `max(dot, 0)` drives
    west, north and down all to exactly the ambient floor: three distinct
    faces at one value, so an outside corner between two shaded walls loses
    its edge and the block reads as a flat sticker again — the very thing
    face shading exists to prevent. Wrapping the dot into 0..1 keeps every
    face distinct while preserving the ordering the sun dictates.
  - **Fitted to the range the art was tuned against** (brightest side 0.92,
    darkest face 0.55) rather than raw physical values. The sun's angle
    decides *which* face is brightest — that is the part that was wrong —
    while the overall contrast stays put, so this corrects the lighting
    logic without darkening the whole game as a side effect. Up stays
    exactly 1.0: it is the reference brightness the art was drawn at.

  Net effect: east 0.84 -> 0.92, south 0.90 -> 0.86, west 0.72 -> 0.58,
  north 0.68 -> 0.64, down and up unchanged. Extruded blocks now turn their
  lit face toward the same sun their shadow runs away from.

### Added

- **Assertions that tie face shading to the sun** (`potato_voxel_test`,
  148 checks, up from 126). They derive the expectation from
  `ShadowMap.sunDir()` instead of pinning numbers, so they check the
  *relationship* rather than restating the answer: the sun is east of south,
  therefore east must outshine south; every face keeps its own value so
  corners keep an edge; up is the 1.0 reference; the underside is darkest;
  and the tuned 0.92/0.55 envelope is preserved. They fail against the old
  hand-typed table (146/148) and pass against the derived one.
- **`audit_geometry_rules.lua`** — a second auditor beside the profile one.
  `audit_profile.lua` checks that pins are *well-formed*; this one checks
  that the tuning numbers are *geometrically coherent*, which several of
  them must be and which prose comments asserted but nothing enforced:
  `can_height` must equal `FALLBACK_HEIGHTS.can` ("so anything riding a can
  lands on its rim" — the source's own words, true today at 9/9 by luck of
  maintenance, not by check); `can_well` < `can_height` or the bin is
  hollowed through its own floor; the taper must leave a positive base;
  cap/base ellipses must fit the rows they are read from; every class must
  carry both a height and an ART mode (36/36 today); flat classes must not
  extrude; water must recess. Verified by mutation: six deliberate breakages
  were each caught by the intended code (VG001, VG002, VG008, VG009, VG010,
  VG011).

## [1.4.6] - 2026-08-13

### Fixed

- **A tileset without an image path crashed the world build.** `Structures`
  reads the tile atlas through a `pixels(tileset)` helper that caches by
  image path. Every read of the image was `pcall`-guarded, but the cache
  lookup `atlasData[path]` happens *outside* that `pcall` — so when a
  tileset carried no `image` at all, `path` was nil and Lua raised
  "table index is nil" before the guard could soften anything. The mod's
  stated contract is that missing art degrades to a rougher world and never
  throws; a nil path now returns nil exactly like an unreadable image does.
  Mod-registered tilesets are the reachable case: the engine's own
  `WorldAPI` guards `tileset.image` before use for the same reason, and
  this pass did not.

### Added

- **A geometry suite — the voxel shapes themselves are now tested.** The
  existing suites covered settings, the mesh cache and the loading cover,
  but nothing drove `TileShape`'s resolver or `ChunkMesher`'s geometry: the
  two pieces that decide whether a tile becomes the right solid. That is
  precisely the "voxels drawn wrong" class of defect, and it was untested.
  `tests/voxel_geometry_test.lua` runs the real geometry path headless (it
  is pure Lua by design — no GPU) and asserts, over every available map plus
  a synthetic map built to reach the class vocabulary:
  - index buffers are well-formed — triangle-aligned, in range, and matching
    the reported quad count;
  - no NaN or infinite vertex coordinate ever reaches the buffer (one NaN
    vertex smears a triangle across the screen);
  - geometry stays inside the shadow frustum and above the void floor;
  - meshing the same map twice yields identical geometry, so a cached mesh
    cannot disagree with a freshly built one;
  - flat classes never carry a positive extrusion height (the failure where
    flowers and grass rise as pillars);
  - water recesses below ground, so shorelines keep their lip;
  - every unauthored tile resolves to the class its cell rule dictates.
  230 checks. The crash above was found by this suite and fails against
  1.4.5.

## [1.4.5] - 2026-08-13

### Fixed

- **Mediatek/Mali detection never fired.** The 1.4.4 fix — give every voxel
  rung the HIGH shadow path on Mali GPUs — could not take effect on any real
  device. `love.graphics.getRendererInfo()` returns four separate strings
  (`name, version, vendor, device`), not a table, and the GPU model is the
  fourth of them; the check read `.name` off the first return value. Indexing
  a string does not raise in Lua, so the guard silently fell through and the
  detection answered "not Mali" everywhere, including on the Mali handsets
  the fix was written for. Every one of the four strings is now scanned, so
  MEDIUM/LOW/POTATO/CUSTOM really do take the proven HIGH actor-shadow path
  on those devices.
- The suite agreed with that bug instead of with LÖVE: it stubbed the
  function as `{ name = "Mali-G57 MC2" }`, a shape the API never returns. It
  now drives the real four-string shape with the strings actual Mali, Adreno
  and desktop drivers report, and fails against the 1.4.4 code.
- **Horde mobs were filed under the wrong mod.** Every runtime object the
  horde spawns was stamped `owner = "DRAMATIC_SHAPE"` — the upstream fork's
  id, inherited unchanged through the rename — so the engine's ownership
  check on `removeRuntimeObject` could not answer for objects this mod
  created. The owner is now taken from the live manifest.
- **`mod.exports.version` reported the wrong version.** It was the hardcoded
  literal `"1.6.2-brick.17"` while the manifest said 1.4.4, so every release
  since the rename published a stale number on a public API other mods
  range-check through `mod.find()`. It is now sourced from `mod.version`;
  the upstream lineage moved to its own `mod.exports.upstreamVersion`.

### Changed

- Documentation corrected against the code it describes. `mod.card`
  advertised the VOXEL ladder on hotkey 3 (it is 8), plus V-GRID on 5,
  V-CURVE on 7, WATER on 9 and a SELECT binding — none of which this
  single-ladder build claims; those keys fall through to the engine. The
  DEBUG row was described as a player-facing option in both `mod.card` and
  the README after it had been removed from the menu; it is armed by
  `DS_PERF`. The claimed hotkeys are now asserted by the suite, so they
  cannot drift again.
- Added `DIFFERENCES.md`, required by the project's publishing checklist.
- Removed dead code: an unused row-grouping helper describing a menu layout
  the mod no longer uses, and an unused module binding.

## [1.4.4] - 2026-08-12

### Fixed

- Mediatek/Mali devices: every voxel rung now uses the HIGH shadow path
  (the sprite-layer map) instead of the flat contact-blob fallback. The
  fallback path is what froze the screen on the last frame (the game kept
  running behind it) and dropped the player's shadow on MEDIUM/LOW/POTATO/
  CUSTOM -- the exact rungs that break are the ones HIGH's configuration
  never touches, and users confirmed HIGH works. The decal pass is also
  now crash-proofed so a failing decal can no longer freeze a frame on any
  device.

## [1.4.3] - 2026-08-12

### Fixed

- Black screen with shadows enabled on Mediatek/Mali Android devices. Two
  failure paths are closed: a shadow pass that dies mid-draw can no longer
  leave its offscreen canvas bound (the world was rendering into the shadow
  map, which is the black frame), and NaN values from a degenerate light
  fit can no longer poison the shadow math (NaN comparisons silently pass
  GLSL bounds checks, then black out every fragment they touch). Both now
  fall back to a flat-lit frame for that moment instead of a black screen.

## [1.4.2] - 2026-08-12

### Fixed

- The map cache no longer asks to rebuild on every launch. The game was
  checking the cache with default settings before your save loaded, so a
  save that used a different VOID FILL looked "stale" every time -- even
  when the cache matched your settings perfectly. The check now runs after
  your save (and its options) are loaded, and the BUILD NOW? prompt appears
  over the world instead of the title screen.
- Interrupted builds now resume. If a build is cut short (the app was
  backgrounded, the battery died, a crash), the next launch continues from
  where it stopped instead of starting over or prompting forever.
- The map cache now refreshes itself once when you update to 1.4.2 (the
  cache now remembers more detail about your game data, so old files are
  rebuilt a single time, in the background or on demand).
- Windows: updating the cache info file no longer fails silently, which
  could leave the game asking for a rebuild every launch.
- When a build fails, the game now tells you WHY (a full SD card, a
  read-only folder) instead of a generic "verification failed".
- The cache folder is created more reliably: the game tries the normal
  save-system folder first, then falls back to system commands, and
  double-checks the folder can actually be written to before using it.
  **CACHE STATUS** now shows which method was used (LOVE FS / MKDIR / NONE).
- If the cache folder can't be set up, the game now retries instead of
  quietly disabling the cache for the whole session.
- Boot logging: when the cache is rejected, the game log now explains
  exactly why, which makes "it rebuilds every time" reports much easier to
  diagnose.

## [1.4.1] - 2026-08-12

### Fixed

- The map-cache build now starts on Windows: the cache folder is created with
  Windows-native commands (`if not exist ... mkdir ...` for each level instead
  of the POSIX-only `mkdir -p`, which cmd.exe rejected by treating `-p` as a
  folder name and choking on the `/dev/null` redirect). The build used to fail
  the instant it began after a cache wipe, on every Windows release back to
  1.3.3.

## [1.4.0] - 2026-08-12

### Added

- One build for every device: the DS_BRICK environment switch is gone, so the
  tuned diorama runs identically on everything -- no more desktop/potato
  split.
- The VOXEL ladder is now a set of quality MODES (OFF / HIGH / MEDIUM / LOW /
  POTATO / CUSTOM). Picking a mode applies its tuned preset to every quality
  knob -- WATER, FOREST FX, AA, V-CURVE, V-GRID, 3D-BTL, SHADOWS, SHADOW
  QUALITY and RENDER SCALE -- and changing any knob on its own flips the mode
  to CUSTOM until a named mode is picked again.
- Added a RENDER SCALE row (100% / 75% / 50% / 33%), the single biggest
  frame-budget lever: the modes set it, and moving it on its own also flips
  the mode to CUSTOM.
- The quality knobs (WATER, FOREST FX, AA, V-CURVE, V-GRID, BACK SPRITES) are
  no longer pinned off on every device: each is a switchable row on the VOXEL
  SETTINGS submenu.
- Added a STADIUM SPRITES row (OFF / ON): staged fights use the Pokemon
  Stadium battle models -- skinned and animated -- instead of the flat battle
  pics. It shows while 3D-BTL is on and needs the models built from the
  player's own Pokemon Stadium (US) 1.0 ROM.
- Stadium packs are now compressed with LZ4 -- the same codec as the terrain
  mesh cache -- so the set is roughly 40% smaller on disk and reads back
  faster. Old raw packs and new compressed ones load through the same path.

### Changed

- Stadium models and their discs are lit by a real sun-directional diffuse
  term (an ambient floor plus a diffuse against the actual sun direction)
  instead of a flat axis-aligned guess, so a Pokemon reads as properly
  shaded in the same light the shadow map throws.
- V-GRID now follows the player's setting inside 3D battles (it used to be
  forced on).
- The anti-aliasing fold gains a light crispness (unsharp) term, so
  supersampling no longer washes out the tileset (AntiAlias.SHARP, tunable).

### Fixed

- Stadium models no longer read their own stale shadow: they are cast-only,
  like the flat battle cards, so the glitchy moire that crawled over their
  bodies is gone.

## [1.3.10] - 2026-08-11

### Added

- Added a SHADOWS row (ON / OFF). OFF is the flat-lit diorama: no shadow map
  is drawn, the main pass is sent sunDark=0, and the contact blobs under the
  characters go with it -- in free-roam and staged battles alike, so a device
  that cannot carry the shadow pass can turn it off wholesale rather than
  only dropping the expensive animated-actor layer.
- Added a SHADOW QUALITY row (AUTO / 512 / 1024 / 2048). AUTO is the adaptive
  ladder the pass always ran (the smallest size whose texel stays under a
  target slice of a world pixel, capped at 2048); a fixed rung forces the
  square shadow map's edge in texels whatever the view, so a player can trade
  fill rate and RAM (a 2048 edge is a 16 MB depth pass, re-rasterised
  whenever the shadow signature moves) for finer shadow edges.
- Both rows are visible in every profile: they appear on the VOXEL SETTINGS
  submenu and the mod manager's page whether the device runs the Brick
  profile (which pins every other knob) or the full desktop mod, and stay on
  the menu under the FULL preset.

### Fixed

- The shadow map canvas is now allocated at the fitted resolution rung
  instead of staying pinned to the ladder's smallest size. The 1536 and 2048
  rungs used to render into a 1024 (or 512 on the Brick) map whose fit, depth
  bias and filter were computed for the finer rung; a fixed SHADOW QUALITY
  rung now produces a map of exactly that size, and the Brick HIGH rung's
  documented 1536 edge is real.

## [1.3.9] - 2026-08-11

### Fixed

- The enemy HUD panel is hidden while a wild battle's intro plays its ball
  animation, instead of showing an empty status box over the arena.

### Contributors

- **AverageConsumer** — the wild-intro HUD fix.

## [1.3.7] - 2026-08-11

### Added

- Added a `github` field to the manifest (`ShaneMcGovernIE/potato_voxel`) so the
  launcher enables the Check for updates / Versions / Update flow for
  PotatoVoxel.

### Fixed

- Removed the per-byte Lua checksum pass that ran over every decompressed
  cache payload on load, eliminating a slight hitch when moving between maps
  with the compressed mesh cache enabled. Truncation is still caught by the
  packed-length and raw-length checks.

## [1.3.6] - 2026-08-11

### Added

- Added an opaque Town Map loading cover for cold asynchronous voxel builds. On
  a cold cache the cover stays up until the current map's first terrain mesh is
  ready, so the vanilla 2D world never flashes before the diorama appears. The
  mesh queue keeps pumping behind it, and invisible overworld updates pause
  until the build finishes, failing open if a build ends without terrain or
  voxel mode is turned off. Loading state is exposed through
  `mod.potato_voxel.loading_changed` and `mod.exports.isLoading`.

### Fixed

- Staged battles now honour the engine's `bottomUIVisible()` and
  `statusHUDVisible()` seams before drawing PotatoVoxel's battle backings, so a
  mod hiding the battle UI no longer leaves frosted panels behind.
- The staged-battle front-sprite wrapper now runs before downstream
  `pokemon.sprite` wrappers, asks them for the FRONT variant with a copied
  side context, and propagates `trueColor` back to the caller, so compatible
  sprite-replacing mods apply inside staged battles instead of being bypassed.

### Contributors

- **AverageConsumer** — interoperability with battle UI and sprite mods, and
  the cold mesh-build loading cover.

## [1.3.5] - 2026-08-11

### Fixed

- Fixed long launcher stalls when booting with a complete compressed mesh cache.
- Boot-time cache readiness now validates bounded file headers, fingerprints,
  codecs, packed lengths, and file sizes without reading or decompressing every
  terrain, water, and auxiliary payload.
- Rebuilding a missing cache manifest now uses the same bounded header scan
  instead of decoding the full cache before the title screen.

### Performance

- Full LZ4 decompression, checksum validation, and mesh decoding remain
  deferred until a map actually loads its mesh or an explicit cache
  verification runs, reducing startup I/O and peak memory use.

## [1.3.4] - 2026-08-10

### Added

- Added optional LZ4 compression for large terrain, water, and auxiliary mesh-cache payloads when the runtime supports it and the compressed result is smaller.
- Compressed entries store their codec, raw and packed lengths, and a checksum so damaged or truncated cache files are rejected safely.
- Existing raw cache files remain readable and are repacked lazily when loaded; **PREBUILD CACHE** migrates the complete cache in one pass.
- Added compression-aware cache status labels: **READY CMP**, **READY MIX**, and **READY RAW**, with the detailed **CACHE STATUS** view showing the same state.

### Performance

- Reduces on-disk cache size and the amount of data read from storage during cache loads, especially for large terrain meshes.
- Keeps raw fallback for unsupported runtimes, tiny payloads, or cases where LZ4 would not reduce the size.
- Does not change mesh vertices, UVs, rendering quality, GPU memory use, or steady-state draw cost.

## [1.3.3] - 2026-08-10

### Added

- Added optional optimized 3D battles to the Brick profile, following the VOXEL render-quality scale.
- Reused the existing cached map terrain for staged battle scenes.

### Fixed

- Split battle terrain and Pokemon cards into separate shadow layers to prevent camera-dependent triangle artifacts.
- Battle cards no longer receive their own sun-shadow depth test while continuing to cast shadows onto the arena.
- Lower Brick battle tiers use contact shadows instead of the actor shadow map.

## [1.3.2] - 2026-08-10

### Added

- Added boot-time mesh-cache readiness detection with automatic migration for complete current caches.
- Added **CACHE STATUS** and confirmed **WIPE CACHE** actions under VOXEL SETTINGS.
- Added a cancellable cache-prebuild prompt before CONTINUE and NEW GAME when the cache is incomplete.

### Fixed

- Prebuilds now validate durable terrain, water, and auxiliary files before reporting READY.
- Cache identities now include the active ROM/data revision, preventing stale geometry from being reused across versions.
- Cache completion is finalized immediately after the last job instead of waiting for another frame.

## [1.3.1] - 2026-08-10

### Changed

- Added conflict detection for `BATTLE_ART_VOXEL_FORK` and `DRAMALESS_SHAPE`, showing a clearer warning that two voxel mods should not be installed at the same time.

## [1.3.0] - 2026-08-10

### Performance

- Reduced Building voxel placement cost with anchor-tile candidate indexing while preserving row-major matching and first-claim behavior.
- Reduced Building voxel model-generation cost with cached atlas shade sampling, lower index arithmetic overhead, and dense voxel storage.
- Preserved building geometry, shading, UVs, shadows, seams, and BuildBudget coroutine behavior.

### Fixed

- SELECT no longer changes the Voxel graphics quality ladder; quality remains controlled by the Voxel option and its supported hotkeys.

## [1.2.4] - 2026-08-10

### Fixed

- Fixed performance regressions in POTATO Mode.
- Removed the DEBUG option from the in-game OPTIONS menu; diagnostics remain available only through benchmark instrumentation.

## [1.2.3] - 2026-08-09

### Fixed

- Fixed stretched, screen-spanning overworld NPC shadows on Android by guarding zero-length camera-ray normalization in the mobile shader.
- Kept NPC contact shadows grounded and stable with camera-ward depth bias and pixel-quantized placement.
- Replaced animated NPC shadow silhouettes with fixed contact-shadow blobs so animation frames, mirroring, and jump lift cannot stretch or shimmer shadows.
- Removed the DEBUG option from the in-game options menu.

[1.3.7]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.7
[1.3.6]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.6
[1.3.5]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.5
[1.3.4]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.4
[1.3.3]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.3
[1.3.2]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.2
[1.3.1]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.1
[1.3.0]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.3.0
[1.2.4]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.2.4
[1.2.3]: https://github.com/ShaneMcGovernIE/potato_voxel/releases/tag/v1.2.3
