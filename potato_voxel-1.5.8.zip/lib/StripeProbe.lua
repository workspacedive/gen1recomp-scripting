-- STREAK PROBE -- a bisection tool for the "long diagonal streaks with no
-- object casting them" report.
--
-- Static reading of the source has not settled which pass draws them, and
-- guessing costs a release each time. This turns the question into
-- something the player can answer in under a minute: a single row that
-- silences one suspect at a time, in the order that splits the search
-- space fastest. Whichever rung makes the streaks disappear NAMES the pass.
--
-- The rungs, and what each one proves:
--
--   OFF      Everything on. The baseline -- the streaks should be visible.
--
--   SUN      The whole shadow pass off (ShadowMap.off()). This is the big
--            cut: if the streaks survive it, NOTHING in the shadow system
--            can be responsible -- not the slope bias, not the varying
--            precision, not the frustum edge -- and every remaining rung
--            below is about surface shading instead.
--
--   FILTER   Shadows on, but the 2x2 PCF collapsed to a single tap. Four
--            taps that disagree draw seams the single tap cannot. If the
--            streaks stop here the fault is in the filter's tap spacing,
--            which is where a quantised lookup coordinate shows up.
--
--   EDGE     Shadows on, but the frustum-rim fade forced to 1 (no fade).
--            The rim fade is a smoothstep over the map's border -- four
--            borders, four possible lines. If the streaks stop here they
--            ARE the rim, and the map simply is not covering the view.
--
--   FOG      The distance/height haze off. A per-vertex term interpolated
--            across big quads can band.
--
--   FLAT     Every shading term off: no shadow, no fog, no tint, no grid.
--            Pure albedo. If streaks survive THIS, they are not shading at
--            all -- they are geometry, and the next place to look is the
--            mesh (z-fighting between the terrain body and its border
--            ring, which is four-sided).
--
-- It is deliberately a normal setting rather than a debug key: the report
-- comes from a phone, where there is no console to type into.

-- the mod namespace (see main.lua): V.require loads a sibling module
local V = ...

local ModSetting = V.require("ModSetting")

local StripeProbe = {}

StripeProbe.KEY = "stripeprobe"
StripeProbe.LABEL = "STREAK PROBE"

StripeProbe.setting = ModSetting.new(
  StripeProbe.KEY, StripeProbe.LABEL,
  { "off", "sun", "filter", "edge", "fog", "flat" },
  { "OFF", "NO SUN", "1 TAP", "NO RIM", "NO FOG", "FLAT" })

StripeProbe.HELP =
  "Diagnostic. Silences one rendering pass at a time so a visual fault can "
  .. "be traced to the pass that draws it. NO SUN turns the shadow system "
  .. "off entirely; 1 TAP keeps shadows but stops the 2x2 softening; NO RIM "
  .. "stops the shadow map fading out at its border; NO FOG drops the "
  .. "distance haze; FLAT shows raw texture with no shading at all. Leave "
  .. "on OFF for normal play."

function StripeProbe.mode()
  return StripeProbe.setting:get() or "off"
end

function StripeProbe.active()
  return StripeProbe.mode() ~= "off"
end

-- Whether the shadow pass should run at all.
function StripeProbe.allowShadows()
  local m = StripeProbe.mode()
  return not (m == "sun" or m == "flat")
end

-- Whether the 2x2 filter should spread its taps. False collapses all four
-- onto the centre, which is a single-tap lookup.
function StripeProbe.allowFilter()
  return StripeProbe.mode() ~= "filter"
end

-- Whether the frustum-rim fade applies. False pins `edge` to 1.
function StripeProbe.allowRim()
  return StripeProbe.mode() ~= "edge"
end

function StripeProbe.allowFog()
  local m = StripeProbe.mode()
  return not (m == "fog" or m == "flat")
end

-- FLAT also drops the day tint, the shadow tint and the wireframe, so the
-- surface is nothing but its atlas texel.
function StripeProbe.allowShading()
  return StripeProbe.mode() ~= "flat"
end

return StripeProbe
