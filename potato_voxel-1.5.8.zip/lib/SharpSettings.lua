-- Voxel world mode: the player's knob on image SHARPNESS.
--
-- Why this row exists at all, since "add a sharpness slider" is usually a bad
-- instinct -- a knob that fakes detail on an image that is already correct is
-- just a way to make a good picture worse.
--
-- It is justified here because this mod genuinely RESAMPLES its world image,
-- in both directions, and resampling is exactly the operation that costs real
-- detail:
--
--   * RENDER SCALE below 100% (75 / 50 / 33) renders the scene into a SMALLER
--     canvas which is then stretched back over the window. Bilinear
--     reconstruction is a low-pass filter -- at 50% every silhouette is
--     rebuilt from a quarter of the samples and comes back soft. This is the
--     case the knob is really for, and it is the case a phone is always in.
--
--   * ANTI-ALIAS above OFF renders LARGER and folds back down. That fold
--     already carried a fixed unsharp term (AntiAlias.SHARP = 0.25), tuned by
--     hand and not exposed. Same operation, same justification, no reason for
--     the player to be able to reach one and not the other.
--
-- So the row is not "invent detail". It is "choose how much of what the
-- resampler cost you gets added back". At RENDER SCALE 100% with ANTI-ALIAS
-- OFF nothing is resampled at all, and the knob correctly does nothing --
-- which is why the help text says so rather than pretending otherwise.
--
--   SHARPNESS   OFF / LOW / MEDIUM / HIGH. OFF is the plain fold (the exact
--               behaviour before this row existed, taken as a separate code
--               path rather than as a zero passed to the shader, so "off" is
--               provably off). MEDIUM is the default and matches the 0.25 the
--               AA fold always used, so a fresh install looks like the build
--               that shipped.

-- the mod namespace (see main.lua): V.require loads a sibling module
local V = ...

local ModSetting = V.require("ModSetting")

local SharpSettings = {}

-- the key under options.modOptions.potato_voxel, shared by the row on the
-- OPTIONS menu's VOXEL SETTINGS submenu and the row on the mod manager's
-- own page for this mod, so the two can never disagree
SharpSettings.KEY = "sharpness"
SharpSettings.LABEL = "SHARPNESS"

-- The strengths behind the rungs. MEDIUM (0.25) first: it is both the
-- default and the fallback an unreadable save reads back as, and it is the
-- constant the AA fold was already hard-coded to -- so the mod's look does
-- not change on upgrade unless the player asks it to.
--
-- HIGH stops at 0.45 rather than going to 1.0. Past roughly a half the
-- unsharp starts fighting the neighbourhood clamp in Upscale's shader and
-- the extra strength buys nothing visible -- an option that does nothing is
-- worse than an option that is not there.
SharpSettings.setting = ModSetting.new(
  SharpSettings.KEY, SharpSettings.LABEL,
  { 0.25, 0, 0.12, 0.45 },
  { "MEDIUM", "OFF", "LOW", "HIGH" })

-- The unsharp strength to apply, as a number. 0 means "do not run the pass".
function SharpSettings.amount()
  local ok, v = pcall(function() return SharpSettings.setting:get() end)
  if not ok then return 0.25 end
  return tonumber(v) or 0.25
end

SharpSettings.HELP =
  "How much of the detail lost when the 3D scene is resampled gets added "
  .. "back. It matters most at RENDER SCALE below 100%, where the world is "
  .. "drawn smaller than the window and stretched back up -- bilinear "
  .. "stretching is what makes a 50% picture look soft. It also sets the "
  .. "same term in the ANTI-ALIAS fold. At RENDER SCALE 100% with "
  .. "ANTI-ALIAS OFF nothing is resampled and this row changes nothing. "
  .. "It sharpens what was rendered; it cannot bring back detail that was "
  .. "never drawn."

return SharpSettings
