-- PotatoVoxel: the fold from a sub-native scene canvas back to the display.
--
-- The scene may render below the window resolution (RENDER SCALE: 100 / 75 /
-- 50 / 33%) to keep the frame budget. Something has to put those pixels back
-- on a full-size screen, and that "something" is where sharpness is won or
-- lost -- it is the LAST thing that touches the world image, so whatever it
-- does is what the player actually sees.
--
-- It used to be one bilinear draw. Bilinear is the right *starting* point
-- (nearest at 75% or 33% gives a shimmering, unevenly-weighted grid, because
-- the source and destination pixel lattices do not line up) but on its own it
-- is a low-pass filter: it throws away the high-frequency detail that makes a
-- voxel edge read as an edge. At 50% every silhouette in the diorama is
-- reconstructed from a quarter of the samples and comes back soft.
--
-- So the fold now runs a small SHARPNESS pass over the same draw. The
-- rebuilt image is compared against a blurred copy of itself and the
-- difference is added back -- an unsharp mask, the same operation
-- AntiAlias.resolve already applies when folding a supersampled canvas DOWN.
-- Both directions of the same resampling problem now get the same treatment,
-- which is also why the strength lives in one place (SharpSettings).
--
-- Why not a fancier upscaler? A Lanczos or FSR-style pass wants several
-- texture reads per output pixel plus a reconstruction filter, and this runs
-- on the hardware the RENDER SCALE knob exists FOR -- a phone already at 33%
-- because it could not afford the pixels. A 5-tap unsharp is roughly free by
-- comparison and recovers most of the perceived detail. Being honest about
-- that trade is the point: this is a sharpening filter, not a detail
-- *reconstruction* filter. It cannot invent what was never rendered, and at
-- 33% the picture is still a 33% picture -- just not a smeared one.

-- the mod namespace (see main.lua): V.require loads a sibling module
local V = ...

local SharpSettings = V.require("SharpSettings")

local Upscale = {}

-- What the fold does this frame, for the debug overlay and for anything that
-- wants to describe the pipeline honestly.
function Upscale.kind()
  if SharpSettings.amount() > 0 then return "unsharp" end
  return "bilinear"
end

-- The unsharp fold.
--
--   c    the bilinear reconstruction at this pixel (what the old path
--        returned on its own)
--   blr  the same neighbourhood one DISPLAY pixel out, in four diagonal taps
--   out  c + sharp * (c - blr)
--
-- Alpha-weighted exactly like the AA fold, and for the same reason: the scene
-- canvas is premultiplied, so an unweighted average of RGB drags the colour of
-- transparent texels (which is nothing at all) into the visible ones and haloes
-- every silhouette against the sky.
--
-- The result is clamped to the local neighbourhood MIN/MAX before it is
-- written. That is what stops the classic unsharp failure: an overshoot ring
-- along the very high-contrast edges this art style is made of -- a black
-- outline against bright grass would otherwise grow a white halo and a dark
-- rim, which reads as a cheap filter rather than as a crisper image.
local SHADER = [[
  uniform vec2 wide;       // the unsharp neighbourhood, in uv
  uniform float sharp;     // strength (0 never reaches this shader)
  vec4 effect(vec4 color, Image tex, vec2 tc, vec2 sc) {
    vec4 c = Texel(tex, tc);
    if (c.a <= 0.001) return vec4(0.0);
    vec4 e = Texel(tex, tc + vec2(-wide.x, -wide.y));
    vec4 f = Texel(tex, tc + vec2( wide.x, -wide.y));
    vec4 g = Texel(tex, tc + vec2(-wide.x,  wide.y));
    vec4 h = Texel(tex, tc + vec2( wide.x,  wide.y));
    // un-premultiply to compare colours rather than coverages
    vec3 cc = c.rgb / c.a;
    float aw = e.a + f.a + g.a + h.a;
    if (aw <= 0.001) return c * color;
    vec3 blr = (e.rgb + f.rgb + g.rgb + h.rgb) / aw;
    vec3 p = cc + sharp * (cc - blr);
    // clamp into the neighbourhood so a hard edge cannot ring
    vec3 lo = min(min(e.rgb / max(e.a, 0.001), f.rgb / max(f.a, 0.001)),
                  min(g.rgb / max(g.a, 0.001), h.rgb / max(h.a, 0.001)));
    vec3 hi = max(max(e.rgb / max(e.a, 0.001), f.rgb / max(f.a, 0.001)),
                  max(g.rgb / max(g.a, 0.001), h.rgb / max(h.a, 0.001)));
    lo = min(lo, cc);
    hi = max(hi, cc);
    p = clamp(p, lo, hi);
    return vec4(p * c.a, c.a) * color;
  }
]]

-- Compiled once and cached. `false` means this driver refused it, and the
-- fold silently stays bilinear rather than dropping the world image --
-- the mod's standing rule that a missing effect degrades to the plain
-- picture instead of to a black screen.
local shader
local function getShader()
  if shader == nil then
    if not (love.graphics and love.graphics.newShader) then
      shader = false
      return nil
    end
    local ok, made = pcall(love.graphics.newShader, SHADER)
    shader = (ok and made) or false
  end
  return shader or nil
end

local targets = {}

local function targetFor(slot, w, h)
  local t = targets[slot]
  if not (t and t.w == w and t.h == h) then
    local ok, canvas = pcall(love.graphics.newCanvas, w, h)
    if not (ok and canvas) then return nil end
    if t and t.canvas and t.canvas.release then
      pcall(t.canvas.release, t.canvas)
    end
    t = { canvas = canvas, w = w, h = h }
    targets[slot] = t
  end
  return t.canvas
end

function Upscale.apply(canvas, w, h, slot)
  if not canvas then return canvas end
  local ok, cw, ch = pcall(canvas.getDimensions, canvas)
  if not ok or (cw == w and ch == h) or cw > w or ch > h then
    return canvas
  end
  local target = targetFor(slot or "world", w, h)
  if not target then return canvas end

  -- 0 = OFF: the plain bilinear fold this module always did, byte for byte.
  -- Kept as its own path so the setting's OFF rung is provably the old
  -- behaviour and not "the shader with a zero in it".
  local amount = SharpSettings.amount()
  local sh = amount > 0 and getShader() or nil

  local prevBlend, prevAlpha = love.graphics.getBlendMode()
  pcall(canvas.setFilter, canvas, "linear", "linear")
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.setBlendMode("replace", "premultiplied")
  if sh then
    love.graphics.setShader(sh)
    -- one DISPLAY pixel out, expressed in SOURCE texels: the source has
    -- cw/w texels per display pixel, so that distance in uv is 1/w. Tying
    -- the radius to the display and not to the source keeps the halo the
    -- same visual width at 75% and at 33%, instead of tripling with the
    -- scale factor.
    pcall(sh.send, sh, "wide", { 1 / math.max(1, w), 1 / math.max(1, h) })
    pcall(sh.send, sh, "sharp", amount)
  end
  local drew = pcall(function()
    love.graphics.setCanvas(target)
    love.graphics.clear(0, 0, 0, 0)
    love.graphics.draw(canvas, 0, 0, 0, w / math.max(1, cw), h / math.max(1, ch))
  end)
  love.graphics.setCanvas()
  if sh then love.graphics.setShader() end
  love.graphics.setBlendMode(prevBlend or "alpha", prevAlpha)
  pcall(canvas.setFilter, canvas, "nearest", "nearest")
  return drew and target or canvas
end

function Upscale.invalidate()
  for slot, t in pairs(targets) do
    if t.canvas and t.canvas.release then pcall(t.canvas.release, t.canvas) end
    targets[slot] = nil
  end
  -- the shader survives: it is resolution-independent and recompiling it on
  -- every window resize is pure cost
end

return Upscale
