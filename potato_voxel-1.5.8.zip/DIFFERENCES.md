# Differences from vanilla Gen1Recomp

Required by the [Publishing checklist](https://github.com/bryanthaboi/gen1recomp/wiki/Guide-Publishing)
(§3), in the format of the engine's own `docs/known-differences.md`. The
base game's ledger stays "None currently."; the divergences below are
PotatoVoxel's own.

The engine's rule is that **disabling a mod restores vanilla exactly**.
Everything here is therefore scoped to "while this mod is installed and
enabled"; uninstalling puts every row and behaviour back.

---

## Presentational: what the world looks like

With the VOXEL row on any rung above OFF:

- The overworld draws as **3D geometry** instead of flat tiles.
- **Occlusion is a depth buffer**, not a y-sort, so a building really hides
  what is behind it rather than being sorted around it.
- Characters are drawn as **leaning sprite slabs** with cast shadows.
- Outdoor maps get a **sky** at the 75-degree rung.
- A **day/night clock** reaches the flat 2D overworld as well as the diorama.

None of this changes what the world *is*: the same cells, the same
collision, the same scripts.

## Behavioural: the deliberate exceptions

These are the only places the mod changes what the game *does*, and each is
scoped to a rung the player selects.

1. **Free movement on the 1ST and 3RD rungs.** These two rungs replace the
   grid walk with free, camera-relative movement (`lib/FreeMove.lua`),
   because a camera steered by a mouse demands feet that go where it looks.
   Even there the walk asks the engine's own collision the same questions a
   grid step asks, keeps the player's logical cell synced, and fires the
   engine's own landing pipeline per cell crossed — warps, encounters,
   ledges, gates and scripts all run exactly as themselves. Every other rung
   leaves movement untouched.
2. **Mouse capture on 1ST and 3RD.** The cursor is captured for free look;
   left click is A, right click is B.
3. **NPCs are culled for the length of a battle**, so the wipe plays over an
   empty map.
4. **HORDE MODE** (konami code in the overworld) is a self-contained
   minigame: waves of walkers, score per kill, no pausing. A run is not
   saved; only the best score rides the save slot.

## Engine rows this mod takes over

While installed, these engine-owned OPTIONS rows are removed and pinned,
because each one fights the diorama and would otherwise be a row the player
can set and watch get reverted:

| Row | Pinned to | Why |
|---|---|---|
| `TILT` | off | the flat fake of what this mode does for real |
| `GBC FX` | off | a full-screen present pass over the top of the diorama |
| `BATTLE BG` | `WHITE` | a staged fight fills the window; there are no voids left to fill |

This build ships **one** quality ladder, so it claims only **`8`** (and
either SHIFT) to step VOXEL. The keys the removed TILT and GBC FX rows used
are left to the engine — `3`, `5`, `7` and `9` are *not* claimed and fall
through. Every other knob is a row on the VOXEL SETTINGS screen rather than
a hotkey. Uninstalling restores all three engine rows at whatever they were
last set to.

All PotatoVoxel rows live on a dedicated **VOXEL SETTINGS** screen, reached
from a single launcher row on OPTIONS, rather than being scattered through
the engine's own list.

## Save data

The mod writes only into its own namespaces, which the engine reserves per
mod:

- `save.modData.potato_voxel` — the day/night clock, the horde best score.
- `options.modOptions.potato_voxel` — every quality knob.

Disabling the mod leaves both in place, untouched and inert; nothing in a
vanilla save is rewritten.

## Link play

`affects_link` is `false`. The mod writes no record into any
link-relevant registry: it is a rendering pipeline plus UI, and the
fingerprint is derived from merged data.

## Known limitations

- Needs shader and depth-canvas support. Without them the rows still cycle
  but the world stays 2D and battles draw plainly — a fallback, never an
  error.
- The **STADIUM** rungs need Pokemon Stadium (US) 1.0 battle models, and the
  mod ships none of them — they are that game's data. The player supplies
  the ROM; the models are built into the save directory and the ROM itself
  is not kept.
- Three species (Exeggutor, Tangela, Magmar) have standby loops that are
  corrupt in the source extraction and are held at their bind pose.
- Terrain meshes are cached per map, so the first frame after entering a
  large map costs a build.
- Rooms have no ceilings, so a first-person look over an interior wall shows
  the void the diorama always had behind it.
- **VR** is Windows x64 only and needs the OpenXR loader restored from
  upstream; on any other platform the VR row is absent.
- HORDE MODE needs the 3D pass.

## What this mod does not do

- It ships **no ROM-derived bytes** (`modkit lint` clean: MK301–MK304).
- It declares **no Gen 2 game**, so a Gold boot skips it rather than
  half-applying it. `modkit gen2check` reports the work that a Gen 2 claim
  would require; until that work is done, not claiming it is the honest
  answer.
